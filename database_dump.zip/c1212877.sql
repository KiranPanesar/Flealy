-- phpMyAdmin SQL Dump
-- version 3.5.3
-- http://www.phpmyadmin.net
--
-- Host: ephesus.cs.cf.ac.uk
-- Generation Time: Dec 03, 2013 at 01:48 AM
-- Server version: 5.1.63
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `c1212877`
--

-- --------------------------------------------------------

--
-- Table structure for table `cards`
--

CREATE TABLE IF NOT EXISTS `cards` (
  `card_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `last_four_digits` int(11) NOT NULL,
  `type` varchar(32) NOT NULL,
  `stripe_card_id` varchar(128) NOT NULL,
  `exp_month` int(11) NOT NULL,
  `exp_year` int(11) NOT NULL,
  `stripe_fingerprint` varchar(64) NOT NULL,
  PRIMARY KEY (`card_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE IF NOT EXISTS `carts` (
  `cart_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`cart_id`),
  KEY `user_id` (`user_id`),
  KEY `item_id` (`item_id`),
  KEY `user_id_2` (`user_id`),
  KEY `cart_id` (`cart_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE IF NOT EXISTS `items` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `price` float NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `latitude` varchar(255) NOT NULL,
  `longitude` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `average_rating` float NOT NULL,
  PRIMARY KEY (`item_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`item_id`, `name`, `description`, `price`, `image_url`, `latitude`, `longitude`, `user_id`, `average_rating`) VALUES
(9, ' Best coffee beans!', 'Imported from the best place to make coffee in the world. Produced by the best plants. It tastes damn good.', 6.25, 'http://www.cabercoffee.com/Media/Default/images/Drinks/Espresso/beans-index-4.jpg', '51.488717', '-3.175950', 12, 1),
(10, 'Daily Routine - 12x18', 'The mantra for creating awesome products. Perfect for any productive environment. Get some startup motivation. Size: 12x18. Frame not included.', 30, 'http://d3u67r7pp2lrq5.cloudfront.net/product_photos/8974741/Screen_20Shot_202013-11-17_20at_209.19.08_20PM_original.png', '51.490962', '-3.178310', 12, 0),
(18, 'Apartment w/great view (PPM)', 'This apartment has a stunning view over the city. The building has a grocery store, free-to-use gym and 24/7 doorman. Excellent price.', 1000, 'https://project.cs.cf.ac.uk/K.Panesar/lab2/Flealy/api/media/b4874903218b57dab102d3e0473fdd6107208cfd.png', '51.48921178930781', '-3.1728708744049072', 13, 1),
(19, 'Chai Latte', 'Enjoy the warm, aromatic flavours of a chai latte at Joe''s Coffee. We make your drink with black tea and spices like cinnamon, cardamom and fennel â€“ All boiled up with milk. Then we add a shot of espresso for your caffeine kick!', 2.25, 'https://project.cs.cf.ac.uk/K.Panesar/lab2/Flealy/api/media/a9e02c52c0a517c3442a18f5acf871e07d48e242.png', '51.488710336147825', '-3.1775593757629395', 15, 0),
(21, 'Banana Pancakes', 'The perfect way to start your morning. Come to Joe''s Coffee and enjoy a stack of freshly-made banana pancakes for breakfast.', 3.75, 'https://project.cs.cf.ac.uk/K.Panesar/lab2/Flealy/api/media/09d76d4c841ad521c844a377aefb06d2ef4569fc.png', '51.488656892022036', '-3.1776022911071777', 15, 0),
(22, 'Oolong Tea', 'An incredibly popular Chinese tea famous for it''s clean, light flavour is growing in demand at Joe''s Coffee. Oolong is a blend of green and black teas with a perfect flavour balance of dark with sweet. ', 2.25, 'https://project.cs.cf.ac.uk/K.Panesar/lab2/Flealy/api/media/bee446e9b0c5e7f298031611594311b19c9cdeba.png', '51.48857672571589', '-3.177473545074463', 15, 0),
(23, 'Cappuccino', 'A classic Italian coffee. Prepared with a shot of espresso in hot milk, finished with a steamed-milk foam. Stop by Joe''s Coffee and try it out today!', 2.75, 'https://project.cs.cf.ac.uk/K.Panesar/lab2/Flealy/api/media/42f8e475cedaf676c3197f40476de91928df9edc.png', '51.4886034478336', '-3.177473545074463', 15, 0),
(24, 'Chicago-style Hot Dog', 'An all-beef frankfurter topped with mustard, pickles, white onion and a pinch of celery salt. This is a classic all the way from our home town of Chicago, Illinois and now available at your local Fast Track Diner!', 3.5, 'https://project.cs.cf.ac.uk/K.Panesar/lab2/Flealy/api/media/8c41bcf20e2f0bafdc9a295ff7dd656972a9d675.png', '51.490073140188834', '-3.169534206390381', 20, 0),
(25, 'Chicago Deep Dish Pizza', 'Pepperoni, mozzarella, more pepperoni, more mozzarella and then a whole load of diced tomatoes on top â€“ That''s a Chicago deep dish pizza. Available in various different toppings at Fast Track Diner!', 8.45, 'https://project.cs.cf.ac.uk/K.Panesar/lab2/Flealy/api/media/c1aad3687f01bca9bb7be7711032383adec5edb1.png', '51.490022620300415', '-3.169507384300232', 20, 1),
(26, 'Bacon Double Cheese Burger', 'Five Guys Burgers and Fries, as the name suggests, are famous for their delicious burgers and fries! Originally only available in America, you can now get their burgers inside Fast Track Diner!', 4.55, 'https://project.cs.cf.ac.uk/K.Panesar/lab2/Flealy/api/media/2470bf5eba2a6c65632a02c4d94cc2f0a439fe45.png', '51.489995899014474', '-3.1694000959396362', 20, 0);

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE IF NOT EXISTS `purchases` (
  `purchase_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `card_id` varchar(32) NOT NULL,
  `stripe_transaction_id` varchar(255) NOT NULL,
  `purchase_epoch` int(11) NOT NULL,
  PRIMARY KEY (`purchase_id`),
  KEY `item_id` (`item_id`),
  KEY `buyer_id` (`buyer_id`),
  KEY `card_id` (`card_id`),
  KEY `card_id_2` (`card_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=42 ;

--
-- Dumping data for table `purchases`
--

INSERT INTO `purchases` (`purchase_id`, `item_id`, `buyer_id`, `card_id`, `stripe_transaction_id`, `purchase_epoch`) VALUES
(35, 10, 13, 'card_10338c2LkSaODyguoQPfjM25', 'tok_10338d2LkSaODyguMwZGG0xq', 1386012362),
(36, 9, 13, 'card_10338d2LkSaODygukpiSauEN', 'tok_10338d2LkSaODyguo9NT0y8a', 1386012387),
(37, 9, 12, 'card_10339u2LkSaODyguFImvtfSV', 'tok_10339u2LkSaODygusUW4M7gw', 1386017116),
(38, 18, 16, 'card_1033Dd2LkSaODygubVvfYJTE', 'tok_1033Dd2LkSaODygucnEJLDTu', 1386031064),
(39, 10, 16, 'card_1033Dd2LkSaODygubVvfYJTE', 'tok_1033Dd2LkSaODygucnEJLDTu', 1386031064),
(40, 10, 16, 'card_1033Dd2LkSaODygubVvfYJTE', 'tok_1033Dd2LkSaODygucnEJLDTu', 1386031064),
(41, 25, 13, 'card_1033Ee2LkSaODyguzPI3SyZC', 'tok_1033Ee2LkSaODyguciQec5Gr', 1386034872);

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE IF NOT EXISTS `ratings` (
  `rating_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `rater_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL COMMENT '1 == thumbs up, 0 == thumbs down',
  PRIMARY KEY (`rating_id`),
  KEY `item_id` (`item_id`),
  KEY `rater_id` (`rater_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `ratings`
--

INSERT INTO `ratings` (`rating_id`, `item_id`, `rater_id`, `rating`) VALUES
(24, 9, 13, 1),
(25, 10, 13, 0),
(26, 18, 16, 1),
(27, 10, 16, 0),
(28, 25, 13, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL,
  `email` varchar(128) NOT NULL,
  `password` varchar(64) NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `location` varchar(128) NOT NULL,
  `description` varchar(255) NOT NULL,
  `sales` int(11) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password`, `image_url`, `location`, `description`, `sales`) VALUES
(12, 'kiran', 'kiransinghpanesar@googlemail.com', 'df24c0e28b8695918120e11730d322e06fba7a04', 'http://f.cl.ly/items/2O3f3L1J0B200Z3g0m2d/Image%202013.11.26%2021%3A44%3A53.png', 'Cardiff, Wales', 'I create numerous motivational startup posters. I also sell tasty coffee!', 2),
(13, 'kiranp', 'kiran@mobilexlabs.com', '187a0dbd9e599a862adb4eeb45006ba7546ae13b', 'http://f.cl.ly/items/2O3f3L1J0B200Z3g0m2d/Image%202013.11.26%2021%3A44%3A53.png', 'Cardiff, Wales', 'My shop is dedicated to selling high-quality, hand-made soaps. Need a special order? Just let me know and I''ll be happy to help!', 10),
(15, 'CoffeeWithJoe', 'joe@coffee.com', 'ff7403f51a735371a475ab6f1a1bf50ce0e3e35d', 'http://localhost:8888/api/media/bb69d0fd41672b59656c40e7d4b6b75c3ad094cd.png', 'Cardiff', 'Joe''s Coffee is a coffee shop based in Cardiff! We serve coffee all day, breakfast until 12PM, lunch until 4PM and light dinner until 9PM. Drop by and try us out!', 0),
(16, 'dandanarno', 'dandanarno@gmail.com', '8f72548218ba454ee5b49655524d74abebb9b4b0', 'https://project.cs.cf.ac.uk/K.Panesar/lab2/Flealy/api/media/d8727e382dc5062d13d298cf131f65829ec555b8.png', 'Cardiff', 'Um... some witty, erudite and completely disingenuous description of myself.', 0),
(20, 'FastTrackDiner', 'fast.track.diner@gmail.com', '112330abd55d43735eda9c597087ce277c471a60', 'https://project.cs.cf.ac.uk/K.Panesar/lab2/Flealy/api/media/c1e21974073c0218303767ea026661f503be5a86.png', 'Cardiff', 'Fast Track has been rated the best American diner in Chicago for 15 years running â€“ And now they''ve opened a diner in Cardiff. Enjoy!', 0);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cards`
--
ALTER TABLE `cards`
  ADD CONSTRAINT `cards_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `carts`
--
ALTER TABLE `carts`
  ADD CONSTRAINT `carts_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `carts_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `items_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `purchases`
--
ALTER TABLE `purchases`
  ADD CONSTRAINT `purchases_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `purchases_ibfk_2` FOREIGN KEY (`buyer_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ratings`
--
ALTER TABLE `ratings`
  ADD CONSTRAINT `ratings_ibfk_2` FOREIGN KEY (`rater_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ratings_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
